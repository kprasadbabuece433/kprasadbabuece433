🫁 Portable Edge E-Nose for VOC-Based Disease Prediction
📌 Project Overview

This project presents a low-cost, non-invasive wearable healthcare system that analyzes exhaled breath to detect diseases using volatile organic compounds (VOCs). The system uses an electronic nose (E-Nose) with multiple gas sensors and performs on-device inference using a TinyML-based neural network, eliminating the need for cloud connectivity.

🎯 Key Features

Non-invasive disease detection using breath analysis
Low-cost and compact wearable design
Real-time VOC monitoring at the edge
Sensor fusion for improved accuracy
TinyML-based neural network for fast prediction
Low power consumption, suitable for continuous monitoring

🧪 Sensors & Hardware Used

MQ-2 Gas Sensor – Detects combustible gases and VOCs
MQ-3 Gas Sensor – Detects alcohol-based VOCs
MQ-135 Gas Sensor – Detects air quality and harmful gases
DHT22 – Temperature and humidity sensing
ESP32 Microcontroller – Edge processing and connectivity

🧠 Software & Technologies

TinyML for on-device inference
Neural Network model for disease classification
TensorFlow Lite Micro (for model deployment)
Flutter Mobile App for data visualization
Arduino IDE / PlatformIO for firmware development

⚙️ System Workflow

Exhaled breath is captured through the sensor array
Sensor fusion combines readings from all gas sensors
Preprocessed data is passed to a TinyML neural network
Disease prediction is performed on the ESP32
Results are displayed on a mobile/web application

📊 Applications

Wearable healthcare monitoring
Early disease screening
Remote health assessment
Smart medical devices
Preventive healthcare systems

🚀 Future Enhancements

Integration of additional biomedical sensors
Support for more disease classes
Real-time clinical validation
Improved mobile app analytics
Battery optimization for long-term use
Arduino Code

File: ESP32_VOC_HealthMonitor.ino
This Arduino sketch reads data from MQ2, MQ3, MQ135, and DHT22 sensors on the ESP32, performs on-device calibration, and uploads VOC and environmental data to the server for real-time health monitoring.