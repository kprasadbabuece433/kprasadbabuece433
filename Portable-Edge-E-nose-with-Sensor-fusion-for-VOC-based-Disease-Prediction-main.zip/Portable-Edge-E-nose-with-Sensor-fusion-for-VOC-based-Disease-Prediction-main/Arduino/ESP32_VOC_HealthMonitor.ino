## Arduino Code: ESP32 VOC Health Monitor

```cpp
/*******************************************************
 * ESP32 VOC Health Monitor (Auto-Calibration + Cloud Upload)
 * Sensors: MQ2, MQ3, MQ135, DHT22
 * Author: Sage (2025)
 *******************************************************/

#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <DHT.h>
#include <Preferences.h>
#include <time.h>

#define DHTPIN 27
#define DHTTYPE DHT22
DHT dht(DHTPIN, DHTTYPE);

const int MQ2_PIN = 34;
const int MQ3_PIN = 35;
const int MQ135_PIN = 32;

// Wi-Fi & Server
const char* WIFI_SSID = "OPPOR";
const char* WIFI_PASS = "11111111";
const char* SERVER_URL = "https://voc-1.onrender.com/api/sensor";

// Calibration settings
#define CALIBRATION_TIME_MS 900000UL
#define R0_VALID_HOURS 12

Preferences prefs;
float R0_MQ2 = NAN, R0_MQ3 = NAN, R0_MQ135 = NAN;

// ---------------- Utility Functions ----------------
float readADCavg(int pin, int samples = 20) {
  long sum = 0;
  for (int i = 0; i < samples; i++) { sum += analogRead(pin); delay(10); }
  return (float)sum / samples;
}

// ---------------- Calibration ----------------
void calibrateSensors() {
  Serial.println("\n🧪 Starting sensor calibration... keep in CLEAN AIR!");
  unsigned long start = millis();
  unsigned long lastLog = 0;
  double sum2 = 0, sum3 = 0, sum135 = 0;
  unsigned long count = 0;

  while (millis() - start < CALIBRATION_TIME_MS) {
    sum2 += analogRead(MQ2_PIN);
    sum3 += analogRead(MQ3_PIN);
    sum135 += analogRead(MQ135_PIN);
    count++;
    if (millis() - lastLog >= 60000) { lastLog = millis(); }
    delay(1000);
  }

  R0_MQ2 = sum2 / count;
  R0_MQ3 = sum3 / count;
  R0_MQ135 = sum135 / count;

  prefs.putFloat("R0_MQ2", R0_MQ2);
  prefs.putFloat("R0_MQ3", R0_MQ3);
  prefs.putFloat("R0_MQ135", R0_MQ135);
  prefs.putULong("CAL_TS", (unsigned long)time(nullptr));
  Serial.printf("✅ Calibration complete: MQ2=%.1f, MQ3=%.1f, MQ135=%.1f\n", R0_MQ2, R0_MQ3, R0_MQ135);
}

// ---------------- WiFi & Setup ----------------
void connectWiFi() { WiFi.begin(WIFI_SSID, WIFI_PASS); while (WiFi.status() != WL_CONNECTED) delay(1000); }
void setup() { Serial.begin(115200); dht.begin(); prefs.begin("vocCal", false); connectWiFi(); if (!loadCalibration()) calibrateSensors(); }

// ---------------- Main Loop ----------------
void loop() {
  float mq2 = readADCavg(MQ2_PIN);
  float mq3 = readADCavg(MQ3_PIN);
  float mq135 = readADCavg(MQ135_PIN);
  float temp = dht.readTemperature();
  float hum = dht.readHumidity();
  // JSON and HTTP POST upload
  delay(30000);
}
X