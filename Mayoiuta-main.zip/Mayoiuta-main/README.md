# Mayoiuta: Open-Source Neural Processing Unit (NPU) Project

> "Loss gradients are irrelevant, let's fit while lost!"

**Mayoiuta** is an open-source Neural Processing Unit (NPU) project aimed at providing a flexible and scalable platform for researchers, developers, and enthusiasts to explore and experiment with various artificial intelligence acceleration technologies.

## Project Vision

Our goals are:

- Openness: Provide a fully open-source NPU design, encouraging community participation and contribution.
- Flexibility: Support a wide range of neural network architectures and computational patterns.
- Scalability: Allow users to adjust the size and performance of the NPU according to their needs.
- Education: Provide a practical platform for learning NPU design and implementation.

## Key Features

- Modular Design: The NPU architecture adopts a modular design, making it easy for users to customize and extend.
- Configurable Parameters: Provides rich configuration parameters, allowing users to adjust the NPU's performance and resource consumption.
- Simulation Environment: Offers a simulator-based simulation environment, making it convenient for users to verify and test before hardware implementation.
- Open-Source Toolchain: Provides an open-source toolchain, including a compiler, assembler, and debugger.
- Detailed Documentation: Provides comprehensive documentation, including design principles, usage methods, and development guides.

## Architecture Overview

Mayoiuta's NPU architecture mainly includes the following core modules:

- Compute Unit (CU): Responsible for executing basic computational operations in neural networks, such as convolution, matrix multiplication, etc.
- Memory Unit (MU): Used to store weights, activation values, and intermediate results.
- Interconnect Network (IN): Responsible for transferring data between CUs and MUs.
- Control Unit (CU): Responsible for controlling the overall operation of the NPU.

## Contributing

We welcome contributions of any kind, including but not limited to:

- Code Contributions: Fixing bugs, adding new features, optimizing performance, etc.
- Documentation Contributions: Improving documentation, adding examples, translating documentation, etc.
- Testing Contributions: Writing test cases, reporting bugs, etc.
- Design Contributions:w Proposing new architectures, optimizing existing designs, etc.

## License

The Mayoiuta project is licensed under the Apache License 2.0. For more details, please see the [LICENSE](LICENSE) file.

## Acknowledgements

Thanks to the Tsukinomori Girls' Academy Computational Technology Research Institute.