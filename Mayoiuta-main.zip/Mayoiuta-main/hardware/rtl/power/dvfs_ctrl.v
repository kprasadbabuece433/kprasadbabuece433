module DVFS_Controller #(
    parameter VOLTAGE_LEVELS = 4,
    parameter FREQ_LEVELS = 4
)(
    input wire clk,
    input wire rst_n,
    input wire [7:0] workload,      // 0-255工作量指示
    output reg [1:0] voltage_level, // 00:0.8V ... 11:1.2V
    output reg [1:0] freq_level     // 00:500MHz ... 11:1.2GHz
);

reg [15:0] history_buffer [0:7];
always @(posedge clk) begin
    history_buffer <= {history_buffer[6:0], workload};
end

// 移动平均计算
wire [10:0] moving_avg;
assign moving_avg = (history_buffer[0] + history_buffer[1] + history_buffer[2] + 
                    history_buffer[3] + history_buffer[4] + history_buffer[5] +
                    history_buffer[6] + history_buffer[7]) >> 3;

// 调节策略
always @(*) begin
    case(moving_avg)
        0-50:   {voltage_level, freq_level} = 4'b00_00;
        51-100: {voltage_level, freq_level} = 4'b01_01;
        101-150:{voltage_level, freq_level} = 4'b10_10;
        default:{voltage_level, freq_level} = 4'b11_11;
    endcase
end

endmodule