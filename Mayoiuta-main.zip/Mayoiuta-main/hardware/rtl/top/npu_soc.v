module NPU_SOC #(
    parameter CORES = 4
)(
    input wire clk,
    input wire rst_n,
    // 外部接口
    input wire [127:0] pcie_data,
    output reg [127:0] ddr_data,
    // 控制信号
    input wire interrupt,
    output reg [31:0] status
);

// 多核互连网络
wire [127:0] noc_data [0:CORES-1];
wire [31:0] noc_ctrl [0:CORES-1];

// 主控制器
npu_controller u_controller(
    .clk(clk),
    .rst_n(rst_n),
    .cores_status(noc_ctrl),
    .global_config(pcie_data[95:0]),
    .interrupt(interrupt)
);

// 计算核心阵列
generate
for (genvar i = 0; i < CORES; i = i + 1) begin
    npu_core #(
        .CORE_ID(i)
    ) u_core (
        .clk(clk),
        .rst_n(rst_n),
        .noc_in(noc_data[i]),
        .noc_out(noc_data[(i+1)%CORES]),
        .ctrl_in(noc_ctrl[i]),
        .ddr_interface(ddr_data)
    );
end
endgenerate

// 性能监控
performance_monitor u_monitor(
    .clk(clk),
    .cores_active(noc_ctrl),
    .ddr_usage(ddr_data[127:96]),
    .power_status(status[31:16])
);

endmodule