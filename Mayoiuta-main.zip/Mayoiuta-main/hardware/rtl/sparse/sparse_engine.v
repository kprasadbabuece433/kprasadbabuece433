module Sparse_Engine #(
    parameter SPARSE_THRESH = 0.3
)(
    input wire clk,
    input wire rst_n,
    input wire [7:0] activation [0:31][0:31],
    input wire [7:0] weight [0:31][0:31],
    output reg [15:0] sparse_result,
    output reg sparse_valid
);

// 零值检测逻辑
reg [31:0] zero_count;
always @(posedge clk) begin
    zero_count = 0;
    for (int i = 0; i < 32; i++) begin
        for (int j = 0; j < 32; j++) begin
            if (activation[i][j] == 0 || weight[i][j] == 0) begin
                zero_count <= zero_count + 1;
            end
        end
    end
    
    // 稀疏度判断
    if (zero_count > (32*32*SPARSE_THRESH)) begin
        sparse_valid <= 1'b1;
        // 触发稀疏计算模式
        sparse_result <= activation * weight; // 使用专用稀疏乘法器
    end else begin
        sparse_valid <= 1'b0;
    end
end

// 稀疏矩阵压缩格式处理
wire [7:0] compressed_act;
wire [4:0] act_idx;
sparse_encoder encoder(
    .in_data(activation),
    .compressed(compressed_act),
    .index(act_idx)
);

wire [7:0] compressed_weight;
wire [4:0] weight_idx;
sparse_encoder encoder_w(
    .in_data(weight),
    .compressed(compressed_weight),
    .index(weight_idx)
);

// 稀疏矩阵乘法核心
always @(posedge clk) begin
    if (act_idx == weight_idx) begin
        sparse_result <= compressed_act * compressed_weight;
    end
end

endmodule