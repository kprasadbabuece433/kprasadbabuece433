module Shape_Adaptor #(
    parameter MAX_DIM = 4096
)(
    input wire clk,
    input wire rst_n,
    input wire [15:0] in_height,
    input wire [15:0] in_width,
    input wire [15:0] kernel_h,
    input wire [15:0] kernel_w,
    output reg [15:0] out_height,
    output reg [15:0] out_width,
    output reg pad_enable
);

// 动态形状计算
always @(posedge clk) begin
    // 输出尺寸计算
    out_height <= (in_height + 2*PAD - kernel_h) / STRIDE + 1;
    out_width  <= (in_width + 2*PAD - kernel_w) / STRIDE + 1;
    
    // 自动填充检测
    pad_enable <= ((in_height % STRIDE != 0) || 
                  (in_width % STRIDE != 0)) ? 1'b1 : 1'b0;
    
    // 边界保护
    if (out_height > MAX_DIM || out_width > MAX_DIM) begin
        $display("Error: Output dimension exceeds maximum limit!");
        out_height <= MAX_DIM;
        out_width <= MAX_DIM;
    end
end

// 运行时配置接口
task configure(
    input [15:0] new_stride,
    input [15:0] new_pad
);
    STRIDE = new_stride;
    PAD = new_pad;
endtask

endmodule