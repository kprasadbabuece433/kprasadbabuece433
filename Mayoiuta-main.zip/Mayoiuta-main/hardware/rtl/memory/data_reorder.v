module Data_Reorder #(
    parameter CHANNELS = 64,
    parameter TILE_SIZE = 8
)(
    input wire clk,
    input wire rst_n,
    input wire [127:0] mem_data,
    output reg [127:0] pe_data,
    input wire [1:0] data_format  // 0:NCHW 1:NHWC 2:Blocked
);

reg [127:0] reorder_buffer [0:CHANNELS/TILE_SIZE-1][0:TILE_SIZE-1];

// 数据格式转换引擎
always @(posedge clk) begin
    case(data_format)
        2'b00: // NCHW -> PE阵列格式
            for (int c = 0; c < CHANNELS; c += TILE_SIZE) begin
                for (int t = 0; t < TILE_SIZE; t++) begin
                    reorder_buffer[c/TILE_SIZE][t] <= 
                        {mem_data[127:112], mem_data[95:80],  // 通道优先
                         mem_data[63:48],  mem_data[31:16]};
                end
            end
        
        2'b01: // NHWC -> PE阵列格式
            for (int h = 0; h < TILE_SIZE; h++) begin
                reorder_buffer[h%4][h/4] <= 
                    {mem_data[127:120], mem_data[95:88],  // 空间优先
                     mem_data[63:56],  mem_data[31:24]};
            end
        
        2'b10: // Blocked格式
            pe_data <= mem_data;  // 直接传递
    endcase
end

// 输出调度
always @(posedge clk) begin
    pe_data <= reorder_buffer[read_ptr];
    read_ptr <= (read_ptr == (CHANNELS/TILE_SIZE-1)) ? 0 : read_ptr + 1;
end

endmodule