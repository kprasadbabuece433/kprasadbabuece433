module Memory_Controller #(
    parameter ADDR_WIDTH = 32,
    parameter DATA_WIDTH = 256,
    parameter BANK_NUM = 8
)(
    input wire clk,
    input wire rst_n,
    // 主机接口
    input wire [ADDR_WIDTH-1:0] host_addr,
    input wire                  host_wr_en,
    input wire [DATA_WIDTH-1:0] host_wr_data,
    output reg [DATA_WIDTH-1:0] host_rd_data,
    // NPU接口
    input wire [ADDR_WIDTH-1:0] npu_addr,
    input wire                  npu_rd_en,
    output reg [DATA_WIDTH-1:0] npu_rd_data
);

reg [DATA_WIDTH-1:0] memory_bank [0:BANK_NUM-1][0:(1<<(ADDR_WIDTH-3))-1];

always @(posedge clk) begin
    if (host_wr_en) begin
        memory_bank[host_addr[2:0]][host_addr[ADDR_WIDTH-1:3]] <= host_wr_data;
    end
    host_rd_data <= memory_bank[host_addr[2:0]][host_addr[ADDR_WIDTH-1:3]];
    
    if (npu_rd_en) begin
        npu_rd_data <= memory_bank[npu_addr[2:0]][npu_addr[ADDR_WIDTH-1:3]];
    end
end

// ECC校验
ecc_checker #(
    .DATA_WIDTH(DATA_WIDTH)
) u_ecc (
    .data_in(host_wr_data),
    .data_out(host_rd_data),
    .syndrome()
);

endmodule