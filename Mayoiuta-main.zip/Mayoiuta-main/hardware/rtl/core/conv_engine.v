module Conv_Engine #(
    parameter KERNEL_SIZE = 3,
    parameter STRIDE = 1,
    parameter PAD = 1
)(
    input wire clk,
    input wire rst_n,
    input wire [7:0] feature_map [0:31][0:31],  // 32x32输入
    input wire [7:0] weight [0:2][0:2],         // 3x3卷积核
    output reg [15:0] conv_result [0:30][0:30]  // 输出特征图
);

// 滑动窗口生成器
reg [7:0] window_buffer [0:2][0:2];
always @(posedge clk) begin
    for (int i = 0; i <= 30; i++) begin
        for (int j = 0; j <= 30; j++) begin
            // 窗口滑动控制
            if (j == 0) begin
                window_buffer[0][0] <= (i > 0) ? feature_map[i-1][j+0] : 0;
                window_buffer[1][0] <= feature_map[i][j+0];
                window_buffer[2][0] <= (i < 31) ? feature_map[i+1][j+0] : 0;
            end else begin
                window_buffer[0][j%3] <= window_buffer[0][(j-1)%3];
                window_buffer[1][j%3] <= window_buffer[1][(j-1)%3];
                window_buffer[2][j%3] <= window_buffer[2][(j-1)%3];
            end
            
            // 卷积计算
            if (j >= 2) begin
                conv_result[i][j-2] <= 
                    (window_buffer[0][0] * weight[0][0]) +
                    (window_buffer[0][1] * weight[0][1]) +
                    (window_buffer[0][2] * weight[0][2]) +
                    (window_buffer[1][0] * weight[1][0]) +
                    (window_buffer[1][1] * weight[1][1]) +
                    (window_buffer[1][2] * weight[1][2]) +
                    (window_buffer[2][0] * weight[2][0]) +
                    (window_buffer[2][1] * weight[2][1]) +
                    (window_buffer[2][2] * weight[2][2]);
            end
        end
    end
end

endmodule