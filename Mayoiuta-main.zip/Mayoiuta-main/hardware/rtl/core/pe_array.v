module PE_Array #(
    parameter DATA_WIDTH = 16,
    parameter ARRAY_SIZE = 8
)(
    input wire clk,
    input wire rst_n,
    input wire [DATA_WIDTH-1:0]  north_in [ARRAY_SIZE-1:0],
    input wire [DATA_WIDTH-1:0]  west_in  [ARRAY_SIZE-1:0],
    output wire [DATA_WIDTH-1:0] south_out[ARRAY_SIZE-1:0],
    output wire [DATA_WIDTH-1:0] east_out [ARRAY_SIZE-1:0],
    input wire [3:0]             opcode,
    input wire                   start,
    output wire                  done
);

wire [DATA_WIDTH-1:0] pe_data_h [ARRAY_SIZE][ARRAY_SIZE];
wire [DATA_WIDTH-1:0] pe_data_v [ARRAY_SIZE][ARRAY_SIZE];

generate
for (genvar i = 0; i < ARRAY_SIZE; i = i + 1) begin : row_gen
    for (genvar j = 0; j < ARRAY_SIZE; j = j + 1) begin : col_gen
        Processing_Element #(
            .DATA_WIDTH(DATA_WIDTH)
        ) u_pe (
            .clk(clk),
            .rst_n(rst_n),
            .north_in(i == 0 ? north_in[j] : pe_data_v[i-1][j]),
            .west_in(j == 0 ? west_in[i] : pe_data_h[i][j-1]),
            .south_out(pe_data_v[i][j]),
            .east_out(pe_data_h[i][j]),
            .opcode(opcode),
            .start(start),
            .done(done)
        );
    end
end
endgenerate

assign south_out = pe_data_v[ARRAY_SIZE-1];
assign east_out = pe_data_h[ARRAY_SIZE][ARRAY_SIZE-1];

endmodule

module Processing_Element #(
    parameter DATA_WIDTH = 16
)(
    input wire clk,
    input wire rst_n,
    input wire [DATA_WIDTH-1:0] north_in,
    input wire [DATA_WIDTH-1:0] west_in,
    output reg [DATA_WIDTH-1:0] south_out,
    output reg [DATA_WIDTH-1:0] east_out,
    input wire [3:0] opcode,
    input wire start,
    output reg done
);

reg [DATA_WIDTH-1:0] accumulator;
reg [DATA_WIDTH-1:0] weight_reg;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        accumulator <= 0;
        weight_reg <= 0;
        done <= 0;
    end else begin
        case(opcode)
            4'h1: begin
                weight_reg <= west_in;
                done <= 1;
            end
            4'h2: begin
                accumulator <= accumulator + (north_in * weight_reg);
                done <= 1;
            end
            4'h3: begin
                south_out <= north_in;
                east_out <= west_in;
                done <= 1;
            end
            default: done <= 0;
        endcase
    end
end

endmodule