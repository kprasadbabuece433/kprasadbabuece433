module Adaptive_PE #(
    parameter INT8_MODE = 1,
    parameter FP16_MODE = 0
)(
    input wire clk,
    input wire rst_n,
    input wire [3:0] precision_mode,
    input wire [31:0] din_a,
    input wire [31:0] din_b,
    output reg [31:0] dout
);

// 多精度计算单元
always @(posedge clk) begin
    if (!rst_n) dout <= 0;
    else begin
        case(precision_mode)
            4'b0001: // INT8模式
                dout <= $signed(din_a[7:0]) * $signed(din_b[7:0]);
            4'b0010: // FP16模式
                dout <= fp16_mult(din_a[15:0], din_b[15:0]);
            4'b0100: // BFLOAT16
                dout <= {din_a[31:16], 16'b0} * {din_b[31:16], 16'b0};
            default: // INT16
                dout <= $signed(din_a) * $signed(din_b);
        endcase
    end
end

// IEEE 754半精度浮点乘法实现
function [15:0] fp16_mult;
    input [15:0] a, b;
    begin
        fp16_mult[15] = a[15] ^ b[15];
        // 指数处理
        if (a[14:10] == 0 || b[14:10] == 0) 
            fp16_mult[14:10] = 0;
        else 
            fp16_mult[14:10] = a[14:10] + b[14:10] - 15;
        // 尾数处理
        fp16_mult[9:0] = (a[9:0] * b[9:0]) >> 10;
    end
endfunction

endmodule