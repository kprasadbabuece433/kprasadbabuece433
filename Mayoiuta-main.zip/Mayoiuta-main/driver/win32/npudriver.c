#include "npudriver.h"

NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath);
EVT_WDF_DRIVER_DEVICE_ADD NpuEvtDeviceAdd;
EVT_WDF_DEVICE_PREPARE_HARDWARE NpuEvtPrepareHardware;
EVT_WDF_IO_QUEUE_IO_DEVICE_CONTROL NpuEvtIoDeviceControl;
EVT_WDF_INTERRUPT_ISR NpuEvtInterruptIsr;
EVT_WDF_INTERRUPT_DPC NpuEvtInterruptDpc;

NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath) {
    WDF_DRIVER_CONFIG config;
    NTSTATUS status;

    WDF_DRIVER_CONFIG_INIT(&config, NpuEvtDeviceAdd);
    config.DriverPoolTag = 'UPN';

    status = WdfDriverCreate(DriverObject, RegistryPath, WDF_NO_OBJECT_ATTRIBUTES, &config, WDF_NO_HANDLE);
    if (!NT_SUCCESS(status)) {
        KdPrint(("WdfDriverCreate failed: 0x%x\n", status));
    }
    return status;
}

NTSTATUS NpuEvtDeviceAdd(WDFDRIVER Driver, PWDFDEVICE_INIT DeviceInit) {
    NTSTATUS status;
    WDFDEVICE device;
    PDEVICE_CONTEXT devContext;
    WDF_PNPPOWER_EVENT_CALLBACKS pnpCallbacks;
    WDF_OBJECT_ATTRIBUTES attributes;
    WDF_INTERRUPT_CONFIG interruptConfig;
    WDF_IO_QUEUE_CONFIG ioQueueConfig;

    WDF_PNPPOWER_EVENT_CALLBACKS_INIT(&pnpCallbacks);
    pnpCallbacks.EvtDevicePrepareHardware = NpuEvtPrepareHardware;
    WdfDeviceInitSetPnpPowerEventCallbacks(DeviceInit, &pnpCallbacks);

    WDF_OBJECT_ATTRIBUTES_INIT_CONTEXT_TYPE(&attributes, DEVICE_CONTEXT);
    status = WdfDeviceCreate(&DeviceInit, &attributes, &device);
    if (!NT_SUCCESS(status)) {
        return status;
    }

    devContext = GetDeviceContext(device);
    devContext->Device = device;

    // 创建中断对象
    WDF_INTERRUPT_CONFIG_INIT(&interruptConfig, NpuEvtInterruptIsr, NpuEvtInterruptDpc);
    interruptConfig.InterruptTranslated = WdfUseHardwareInterrupts;
    status = WdfInterruptCreate(device, &interruptConfig, WDF_NO_OBJECT_ATTRIBUTES, &devContext->Interrupt);
    if (!NT_SUCCESS(status)) {
        return status;
    }

    // 初始化DMA
    WDF_DMA_ENABLER_CONFIG dmaConfig;
    WDF_DMA_ENABLER_CONFIG_INIT(&dmaConfig, WdfDmaProfileScatterGather64, 64);
    status = WdfDmaEnablerCreate(device, &dmaConfig, WDF_NO_OBJECT_ATTRIBUTES, &devContext->DmaEnabler);
    if (!NT_SUCCESS(status)) {
        return status;
    }

    // 创建IO队列
    WDF_IO_QUEUE_CONFIG_INIT_DEFAULT_QUEUE(&ioQueueConfig, WdfIoQueueDispatchParallel);
    ioQueueConfig.EvtIoDeviceControl = NpuEvtIoDeviceControl;
    status = WdfIoQueueCreate(device, &ioQueueConfig, WDF_NO_OBJECT_ATTRIBUTES, &devContext->IoQueue);
    if (!NT_SUCCESS(status)) {
        return status;
    }

    return status;
}

NTSTATUS NpuEvtPrepareHardware(WDFDEVICE Device, WDFCMRESLIST ResourcesRaw, WDFCMRESLIST ResourcesTranslated) {
    PCM_PARTIAL_RESOURCE_DESCRIPTOR resource;
    ULONG resourceCount;
    PDEVICE_CONTEXT devContext = GetDeviceContext(Device);
    NTSTATUS status = STATUS_SUCCESS;

    resourceCount = WdfCmResourceListGetCount(ResourcesTranslated);
    for (ULONG i = 0; i < resourceCount; i++) {
        resource = WdfCmResourceListGetDescriptor(ResourcesTranslated, i);
        
        if (resource->Type == CmResourceTypeMemory) {
            devContext->Registers = (NPU_REGISTERS*)MmMapIoSpaceEx(
                resource->u.Memory.Start,
                resource->u.Memory.Length,
                PAGE_READWRITE | PAGE_NOCACHE);
            
            if (!devContext->Registers) {
                return STATUS_INSUFFICIENT_RESOURCES;
            }
        }
    }

    // 初始化硬件
    WRITE_REGISTER_ULONG(&devContext->Registers->ControlStatus, 0x1); // 复位NPU
    KeStallExecutionProcessor(100);
    WRITE_REGISTER_ULONG(&devContext->Registers->ControlStatus, 0x0); // 解除复位

    return status;
}

VOID NpuEvtIoDeviceControl(WDFQUEUE Queue, WDFREQUEST Request, size_t OutputBufferLength,
                           size_t InputBufferLength, ULONG IoControlCode) {
    WDFDEVICE device = WdfIoQueueGetDevice(Queue);
    PDEVICE_CONTEXT devContext = GetDeviceContext(device);
    NTSTATUS status = STATUS_SUCCESS;
    size_t length = 0;

    switch (IoControlCode) {
        case IOCTL_NPU_EXECUTE: {
            // 启动NPU运算
            WdfSpinLockAcquire(devContext->DmaLock);
            WRITE_REGISTER_ULONG(&devContext->Registers->ControlStatus, 0x2); // 启动计算
            WdfSpinLockRelease(devContext->DmaLock);
            length = 0;
            break;
        }

        case IOCTL_NPU_LOAD_WEIGHTS: {
            PVOID inputBuffer;
            size_t bufferSize;
            WDFMEMORY dmaMemory;
            PVOID dmaBuffer;
            WDFDMATRANSACTION dmaTransaction;

            status = WdfRequestRetrieveInputBuffer(Request, 0, &inputBuffer, &bufferSize);
            if (!NT_SUCCESS(status)) {
                break;
            }

            // 分配DMA内存
            status = WdfDmaTransactionCreate(devContext->DmaEnabler, 
                WDF_DMA_ENABLER_CONFIG_REQUIRE_SINGLE_TRANSFER,
                WDF_NO_OBJECT_ATTRIBUTES, &dmaTransaction);
            if (!NT_SUCCESS(status)) {
                break;
            }

            status = WdfMemoryCreateFromBuffer(
                WDF_NO_OBJECT_ATTRIBUTES,
                inputBuffer,
                bufferSize,
                &dmaMemory);
            if (!NT_SUCCESS(status)) {
                break;
            }

            // 配置DMA传输
            WdfDmaTransactionInitialize(
                dmaTransaction,
                WdfDmaDirectionWriteToDevice,
                WdfMemoryGetBuffer(dmaMemory, NULL),
                bufferSize,
                devContext->Registers->DmaDest,
                devContext->Registers->DmaSource);

            WdfDmaTransactionExecute(dmaTransaction, WDF_NO_CONTEXT);
            WdfObjectDelete(dmaTransaction);
            length = bufferSize;
            break;
        }

        case IOCTL_NPU_GET_STATUS: {
            ULONG statusReg = READ_REGISTER_ULONG(&devContext->Registers->ControlStatus);
            status = WdfRequestCopyBuffer(Request, &statusReg, sizeof(ULONG));
            length = sizeof(ULONG);
            break;
        }

        default:
            status = STATUS_INVALID_DEVICE_REQUEST;
            break;
    }

    WdfRequestCompleteWithInformation(Request, status, length);
}

BOOLEAN NpuEvtInterruptIsr(WDFINTERRUPT Interrupt, ULONG MessageID) {
    PDEVICE_CONTEXT devContext = GetDeviceContext(WdfInterruptGetDevice(Interrupt));
    ULONG status = READ_REGISTER_ULONG(&devContext->Registers->ControlStatus);

    if (status & 0x80000000) { // 检查中断标志
        // 确认中断
        WRITE_REGISTER_ULONG(&devContext->Registers->InterruptMask, 0x1);
        return TRUE;
    }
    return FALSE;
}

VOID NpuEvtInterruptDpc(WDFINTERRUPT Interrupt, WDFOBJECT AssociatedObject) {
    PDEVICE_CONTEXT devContext = GetDeviceContext(WdfInterruptGetDevice(Interrupt));
    // 处理完成通知
    // TODO: 实现完成队列处理
}